function userResponse(response) {
    if (response === 'bad') {
        document.getElementById('assistant').classList.add('hidden');
        document.getElementById('password-screen').classList.remove('hidden');
    }
}

function checkPassword() {
    let password = document.getElementById('password-input').value;
    if (password.toLowerCase() === "i love you") {
        document.getElementById('password-screen').classList.add('hidden');
        document.getElementById('letter-screen').classList.remove('hidden');
    } else {
        alert("Incorrect password. Try again!");
    }
}

function openLetter() {
    document.querySelector('.envelope').classList.add('open');
}